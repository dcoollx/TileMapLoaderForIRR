#pragma once
#include <irrlicht.h>
#include <vector>

using namespace irr;
using namespace irr::core;
using namespace irr::scene;
using namespace irr::video;
 namespace MapManager
{

	class IMapManager
	{
		friend class cTile;
		friend class NPC;
		friend class player;
		
	public:
		ITexture* sourceImage = NULL;
		IMapManager(int x, int y, IrrlichtDevice* device, IVideoDriver* driver);//contructor must know the number of tiles in the map
		IMapManager(int size, IrrlichtDevice* device, IVideoDriver* driver);//contructor must know the number of tiles in the map
		~IMapManager();
		void renderMap(std::vector<cTile> tiles);
		bool loadMap(stringw xml);
		std::vector<cTile> createTiles();
		int allTiles;// all number of tiles managed by this instance
	protected:
		
		const stringw mapTag = L"map"; //map tag
		const stringw tilesetTag = L"tileset";
		const stringw imageTag = L"image";
		const stringw layerTag = L"layer";
		const stringw dataTag = L"data";
		const stringw tileTag = L"tile";
		int tileHeight;
		int tileWidth;
		int mapSize = 0;
		dimension2d<u32> tileDim();
		int layerCount = 0;
		int tilespace_X;// represent X_space inbetween tiles
		int tilespace_Y;//represent Y space inbetween tiles
		rect<u32> sourecRect();//square representing tile to draw from													
		int mapHeight;// measured in tiles
		int mapWidth;//measured in tiles
	    stringw tileSource;// file name of file containing image
		int sourceimgHeight;
		int sourceimgWidth;
		int layernumber = 0;
		std::vector<int> data;// array storing all tile info 
		int increment = 0;//tiles drawn
		stringw lastsection;
		
		//temp irr device
		IVideoDriver* vdr;
		IrrlichtDevice *Irrdevice;
	};

	class cTile
	{
		
		friend IMapManager;
	protected:
		int Gid = -1; // initialized at a negative number because zero is a valid number represent the global id number of tile ie its texture
		bool bDraw = true;//allow the method rendermap() to draw me
	private:
		int imgIndex_x;// X coordinate of where to draw from
		int imgIndex_y;
		int mapIndex_x;
		int mapIndex_y;//Y coordinate of where to draw to
		rect<s32> TextureSq;
	
	public:
		position2d<s32> Position;
		int idenity;
		bool isSolid = false;
		int offset = 0;
		cTile()
		{

		}

		~cTile()
		{

		}
		virtual void animate()// TODO make into virtual function
		{

		}
		void remove() //removes tile
		{
			bDraw=false;
		
		}
		void setGid(int gid, IMapManager* mapmgr)
		{
			imgIndex_x = (((gid % (mapmgr->sourceimgWidth / mapmgr->tileWidth)))*mapmgr->tileWidth);// +(gid % (mapmgr->sourceimgWidth / mapmgr->tileWidth)); //TODO: simplify these formulas(gid%(#ofrows) = x
			imgIndex_y = (ceilf(gid / (mapmgr->sourceimgWidth / mapmgr->tileWidth)) * mapmgr->tileHeight);// +(ceilf(gid / (mapmgr->sourceimgWidth / mapmgr->tileWidth)));
			mapIndex_y = ( idenity/ mapmgr->mapWidth)*mapmgr->tileHeight;
			mapIndex_x = (idenity % mapmgr->mapWidth)*mapmgr->tileWidth;
			position2d<s32> sorposition(imgIndex_x+mapmgr->tilespace_X, imgIndex_y+mapmgr->tilespace_Y);
			Position = position2d<s32>(mapIndex_x, mapIndex_y);
			TextureSq = rect<s32>(sorposition, dimension2d<u32>(mapmgr->tileWidth, mapmgr->tileHeight));
			Gid = gid;
		}
		int cTile::getGid()
		{
			return Gid;
		}
		void setSolid(bool state)
		{
			isSolid = state;

		}
		void draw(IVideoDriver* vdr, ITexture * sourceImage)//params source image
		{
			if (bDraw)
			{
				vdr->draw2DImage(sourceImage, Position, TextureSq, 0, SColor(255, 255, 255, 255), true);
			}
		}
		 void draw(IVideoDriver* vdr, ITexture * sourceImage, SColor color)//params source image
		{
			if (bDraw)
			{
				vdr->draw2DImage(sourceImage, Position, TextureSq, 0, color, true);
			}

		}
		void draw(IVideoDriver* vdr, ITexture * sourceImage, SColor color, bool Alpha)//params source image
		{
			if (bDraw)
			{
				vdr->draw2DImage(sourceImage, Position, TextureSq, 0, color, Alpha);
			}
			else
			{
				//throw exception

			}
		}

	};
}
