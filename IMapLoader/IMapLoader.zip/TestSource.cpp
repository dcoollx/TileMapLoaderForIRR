#include "IMaploader.h"
#include "irrlicht.h"
#include "characters.h" 
#ifdef _MSC_VER
#pragma comment(lib, "Irrlicht.lib")
#pragma comment(linker, "/subsystem:windows /ENTRY:mainCRTStartup")
#define null 0
#endif

using namespace irr;
using namespace irr::video;
using namespace irr::core;
using namespace irr::io;
using namespace irr::gui;
using namespace irr::scene;
using namespace MapManager;
SColor Black = SColor(255, 0, 0, 0);
SColor White = SColor(255, 255, 255, 255);
SColor Gray = SColor(255, 175, 175, 175);
dimension2d<u32> screen(1000, 1000);
//--normal irr device interfaces
IrrlichtDevice *dev = createDevice(EDT_DIRECT3D9);
IVideoDriver* vdr = dev->getVideoDriver();
//----------------------------------you only need one instance of mapmger
IMapManager mapmgr(100,25, dev, vdr);
std::vector<cTile> tiles;// will hold the map


int main()
{
	if (mapmgr.loadMap("Assets/test3.tmx"))//loads map info into mapmanger must be called first before using any other mapmagr calls returns a boolean 
	{
		while (dev->run())
		{
			if (mapmgr.sourceImage != NULL)// optional error checking
			{
				tiles = mapmgr.createTiles();/*returns a vector filled with the data from the tmx file. 
											 use the mapmanger class to access various stats about 
											 the map*/

			}
			else
				return 4;
			vdr->beginScene();//irr begin scene, all drawing happens here
			mapmgr.renderMap(tiles);// draws all tiles in mapmanger
			tiles[0].remove(); // specif tiles can be addressed
			for (int i = 0; i < 2500; i++)
			{
				if (tiles[i].idenity == 3)//identify a tile by its uniqe id
				{
					tiles[i].draw(vdr, mapmgr.sourceImage, Gray);
				}
			}

			vdr->endScene();

		}
	}
	else
		return 1;
	
	return 0;
}
