#pragma once
#include "IMaploader.h"
using namespace MapManager;
class NPC1:cTile
{

	IMapManager *Mapmanger;//the mapmgr this node reports to
protected:
	ITexture* sprites = NULL;
	bool isSolid = true;
public:
	NPC1()
	{

	}
	~NPC1();
	NPC1(IMapManager *mapmgr);
	enum state
	{
		idle,
		run,
		walk,
		hurt,
		dead,
	};



};
class player: NPC1
{	
	bool bDraw = false;// will not be automatically draw by mapmangr
	//TODO add controls
public:
	~player();
	player();
	player::player(stringw spritesheet)//start using a spriteshite
	{
		IrrlichtDevice* dev = createDevice(EDT_NULL);
		IVideoDriver* vdr = dev->getVideoDriver();
		sprites = vdr->getTexture(spritesheet);
		dev->drop();
		vdr->drop();

	}
	int life;
	void animate(state state)
	{
		//swith(state)

	}





};