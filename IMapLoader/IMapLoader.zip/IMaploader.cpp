#include "IMaploader.h"
#include<irrlicht.h>

using namespace irr;
using namespace irr::core;
using namespace irr::io;
using namespace irr::scene;
using namespace irr::video;
using namespace MapManager;


IMapManager::IMapManager(int x, int y, IrrlichtDevice* device, IVideoDriver* driver)
{
	 mapSize = x*y;
	 data.resize(mapSize);
	Irrdevice = device;
	vdr = driver;
}
IMapManager::IMapManager(int size, IrrlichtDevice* device, IVideoDriver* driver)
{
	mapSize = size;
	data.resize(mapSize);
	Irrdevice = device;
	vdr = driver;
}


IMapManager::~IMapManager()
{
}

std::vector<cTile> IMapManager::createTiles()// must call loadmap() first
{

	if (data[1]!=-1)
	{
		allTiles = mapSize;
		std::vector<cTile> tiles(mapSize);
		for (int i = 0; i < mapSize; i++)
		{
			tiles[i].idenity = i;
			tiles[i].setGid(data[i], this);
		}
		return tiles;
	}
	else
	{
		//return NULL;
	}

}//works

void IMapManager::renderMap(std::vector<cTile> tiles)
{ 
	//if(tiles!=NULL)
	for (int i = 0; i <mapSize; i++)
	{
		tiles[i].draw(vdr, sourceImage);
		
	}
}

bool IMapManager::loadMap(stringw xml)
{
	io::IXMLReader *xmlRder = Irrdevice->getFileSystem()->createXMLReader(xml);//loades map file into memory
	if (!xmlRder)
		return false;

	while (xmlRder->read())
	{

		switch (xmlRder->getNodeType())
		{
		case irr::io::EXN_ELEMENT:
		{

			if (mapTag.equals_ignore_case(xmlRder->getNodeName())) // if we havent started and we found the first node
			{
				lastsection = mapTag; //now working on map
				tileHeight = xmlRder->getAttributeValueAsInt(L"tileheight");
				tileWidth = xmlRder->getAttributeValueAsInt(L"tilewidth");
				mapHeight = xmlRder->getAttributeValueAsInt(L"height");
				mapWidth = xmlRder->getAttributeValueAsInt(L"width");
				//font->draw(L"in map tag", rect<s32>(), SColor(255, 0, 0, 0), false, false, NULL);
			}
			else if (tilesetTag.equals_ignore_case(xmlRder->getNodeName()))//in tileset tag
			{
				lastsection = tilesetTag;
				tilespace_X = xmlRder->getAttributeValueAsInt(L"spacing");
				tilespace_Y = xmlRder->getAttributeValueAsInt(L"margin");
			}
			else if (imageTag.equals_ignore_case(xmlRder->getNodeName()))
			{
				sourceimgHeight = xmlRder->getAttributeValueAsInt(L"height");
				sourceimgWidth = xmlRder->getAttributeValueAsInt(L"width");
				  tileSource =xmlRder->getAttributeValueSafe(L"source");
				  //tileSource = "C:/Users/David/Documents/Visual Studio 2013/Projects/IMapLoader/IMapLoader/Debug/Assets/desertTileset.png";
				  sourceImage = vdr->getTexture(io::path(tileSource));
			}
			else if (layerTag.equals_ignore_case(xmlRder->getNodeName()))//reached a layer element increment to keep track of the numbers of layers
			{
			layerCount++;
			}
			else if (dataTag.equals_ignore_case(xmlRder->getNodeName()))// data node
			{/* this is the meat of this function it will use the data here to render the stage*/

			}
			else if (tileTag.equals_ignore_case(xmlRder->getNodeName()))
			{
				if (xmlRder->getAttributeValueAsInt(L"gid") != 0)// prevents reading of trash data
				{
					data[increment] = xmlRder->getAttributeValueAsInt(L"gid") - 1; // works
					if (increment <mapHeight*mapWidth)
						increment++;
				}

			}

		}

		break;
		case irr::io::EXN_ELEMENT_END: //reached the end of an element in most cases just break
		{
			if (dataTag.equals_ignore_case(L"data"))
			{

			}


		}
		break;

		}
	}
	xmlRder->drop();
	return true;
}//works
